<?php
session_start();
$BASE_URL = "http://3dmap-kadaster.test/";
include_once $_SERVER['DOCUMENT_ROOT'] . '/action/fucntion.php';
